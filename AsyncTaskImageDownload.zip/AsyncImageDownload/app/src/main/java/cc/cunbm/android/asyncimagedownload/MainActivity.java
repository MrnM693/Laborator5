package cc.cunbm.android.asyncimagedownload;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.io.InputStream;
import java.net.URL;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;



public class MainActivity extends AppCompatActivity {

    private String url="https://nucbm.github.io/joker.png";
    ImageView img;
    Button downloadBtn;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img=(ImageView) findViewById(R.id.imageView1);
        downloadBtn=(Button) findViewById(R.id.button);

        //ONCLICK
        downloadBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                new Downloader().execute(url);
            }
        });

    }



    private class Downloader extends AsyncTask<String,Void,Bitmap>{
        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub

            super.onPreExecute();

            //CREATE PD,SET PROPERTIES
            pd=new ProgressDialog(MainActivity.this);
            pd.setTitle("Image Downloader");
            pd.setMessage("Downloading...");
            pd.setIndeterminate(false);
            pd.show();
        }

        protected Bitmap doInBackground(String... url) {
            String myurl = url[0];
            Bitmap bm = null;
            InputStream is = null;

            try {
                is = new URL(myurl).openStream();
                //DECODE
                bm = BitmapFactory.decodeStream(is);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return bm;

        }
        @Override
        protected void onPostExecute(Bitmap result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);

            // SET TO IMG
            img.setImageBitmap(result);

            // DISMISS
            pd.dismiss();
        }

    }
}